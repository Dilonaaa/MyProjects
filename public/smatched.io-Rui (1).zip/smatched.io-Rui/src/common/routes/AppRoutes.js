export const AppRoutes = {
    MAIN: '/',
    BLOG: '/blog',
    ARTICLES: '/articles',
    BLOGARTICLE: '/blogarticle',
    CONTACT: '/contact',
}